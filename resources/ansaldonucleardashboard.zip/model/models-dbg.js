sap.ui.define(
	[
		"../model/formatter",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/BindingMode",
		"sap/ui/Device",
	],
	function (formatter, JSONModel, BindingMode, Device) {
		"use strict";

		return {
			createDeviceModel: function () {
				const oModel = new JSONModel(Device);
				oModel.setDefaultBindingMode(BindingMode.OneWay);
				return oModel;
			},
			createMainModel: function () {
				return new JSONModel({
					visibility: false,
					editable: false,
					enabled: false,
					busy: false,
					selected: false,
					isDetail: false,
				});
			},
			createSizesModel: function () {
				return new JSONModel({
					masterPaneSize: "320px",
					detailPaneSize: "auto",
					menuExpanded: true,
				});
			},
			createFilterModel: function () {
				return new JSONModel({
					fromDate: null,
					toDate: null,
					integrationId: [],
					description: [],
					system: [],
					status: "",
				});
			},
			createIntegrationMock: function (oBundle) {
				// mapping IntegrationId -> dati mock
				const mapping = {
					"INT-001": {
						// Cost Center TS
						KOSTL: "CC1001",
						KTEXT: "Cost Center TS",
						BUKRS: "C001",
						DATBI: "20251231",
						DATAB: "20240101",
						OPERA: "INS",
					},
					"INT-001A": {
						KOSTL: "CC1002",
						KTEXT: "Cost Center TS Extra",
						BUKRS: "C001",
						DATBI: "20251231",
						DATAB: "20240101",
						OPERA: "INS",
					},
					"INT-002": {
						// WBE
						PSPNR: "00000001",
						POSID: "WBS-WBE-001",
						POST1: "WBE Element 1",
						PSTRT: "20230101",
						PENDE: "20231231",
						STTXT_EXT: "REL",
						OPERA: "INS",
					},
					"INT-002A": {
						PSPNR: "00000002",
						POSID: "WBS-WBE-002",
						POST1: "WBE Extra Element",
						PSTRT: "20230401",
						PENDE: "20231231",
						STTXT_EXT: "REL",
						OPERA: "INS",
					},
					"INT-003": {
						// Network
						AUFNR: "100000000001",
						KTEXT: "Network 1",
						GSTRP: "20230101",
						GLTRP: "20231231",
						OPERA: "INS",
						STATUS: "INS",
						positions: [
							{
								VORNR: "0001",
								LTXA1: "Operation 1",
								NTANF: "20230110",
								NTEND: "20230120",
								VSTTXT: "REL",
								OPERA: "INS",
								STATUS: "INS",
							},
							{
								VORNR: "0002",
								LTXA1: "Operation 2",
								NTANF: "20230115",
								NTEND: "20230125",
								VSTTXT: "CLSD",
								OPERA: "MOD",
								STATUS: "MOD",
							},
						],
					},
					"INT-003A": {
						AUFNR: "100000000002",
						KTEXT: "Network Extra",
						GSTRP: "20230201",
						GLTRP: "20231231",
						OPERA: "INS",
						STATUS: "ERROR",
						positions: [
							{
								VORNR: "0001",
								LTXA1: "Operation A",
								NTANF: "20230210",
								NTEND: "20230220",
								VSTTXT: "REL",
								OPERA: "INS",
							},
							{
								VORNR: "0002",
								LTXA1: "Operation B",
								NTANF: "20230215",
								NTEND: "20230225",
								VSTTXT: "CLSD",
								OPERA: "MOD",
							},
						],
					},
					"INT-004": {
						// Production Order
						AUFNR: "100001",
						KTEXT: "Production A",
						AUART: "ZP01",
						STTXT: "REL",
						WERKS: "1000",
						PLNBEZ: "Material A",
						GAMNG: 500.0,
						GWEMG: 200.0,
						GSTRP: "20250901",
						GLTRP: "20250910",
						OPERA: "INS",
					},
					"INT-005": {
						// Activity Types
						LSTAR: "ACT001",
						KTEXT: "Plant Maintenance",
						DATBI: "20251231",
						DATAB: "20240101",
						OPERA: "INS",
						positions: [
							{ KOSTL: "CC1001", YEAR: "2025", MONTH: "01", PLAN: "X" },
							{ KOSTL: "CC1002", YEAR: "2025", MONTH: "02", PLAN: "" },
						],
					},
					"INT-006": {
						// Employee TS
						USRID: "jsmith",
						VORNA: "John",
						NACHN: "Smith",
						EMAIL: "john.smith@company.com",
						HIRE_DATE: "20220110",
						BUKRS: "1000",
						WERKS: "2000",
						KOSTL: "CC1001",
						PERSG: "A1",
						PERSK: "A1-FT",
					},
					"INT-007": {
						// Employee S/4
						USRID: "amiller",
						VORNA: "Anna",
						NACHN: "Miller",
						EMAIL: "anna.miller@company.com",
						HIRE_DATE: "20210305",
						BUKRS: "2000",
						WERKS: "3000",
						KOSTL: "CC2001",
						PERSG: "B2",
						PERSK: "B2-PT",
					},
					"INT-008": {
						// Employee ADP
						PSPNR: "00000001",
						POSID: "WBS-IT-001",
						POST1: "IT Infrastructure Upgrade",
						PSTRT: "20230101",
						PENDE: "20231231",
						STTXT_EXT: "REL",
						OPERA: "INS",
					},
					"INT-009": {
						// Cost Center ADP
						KOSTL: "CC1001",
						BUKRS: "C001",
						LTEXT: "Cost Center for IT Department",
						DATBI: "20230101",
						DATAB: "20241231",
						OPERA: "INS",
					},
					"INT-010": {
						// Salary Accounting (Network Operations)
						AUFNR: "100000000001",
						KTEXT: "Salary Accounting",
						GSTRP: "20230101",
						GLTRP: "20231231",
						OPERA: "INS",
						positions: [
							{
								VORNR: "0001",
								LTXA1: "Operation 1",
								NTANF: "20230110",
								NTEND: "20230120",
								VSTTXT: "REL",
								OPERA: "INS",
							},
							{
								VORNR: "0002",
								LTXA1: "Operation 2",
								NTANF: "20230115",
								NTEND: "20230125",
								VSTTXT: "CLSD",
								OPERA: "MOD",
							},
						],
					},
					"INT-011": {
						// Tracking Activities
						USRID: "amiller",
						VORNA: "Anna",
						NACHN: "Miller",
						EMAIL: "anna.miller@company.com",
						HIRE_DATE: "20210305",
						BUKRS: "2000",
						WERKS: "3000",
						KOSTL: "CC2001",
						PERSG: "B2",
						PERSK: "B2-PT",
					},
					"INT-015": {
						Product: "MAT-000123",
						ProductType: "FERT",
						CrossPlantStatus: "01",
						CrossPlantStatusValidityDate: "2025-09-18",
						IsMarkedForDeletion: false,
						ProductOldID: "MAT-OLD-0099",
						GrossWeight: "15.75",
						PurchaseOrderQuantityUnit: "PC",
						SourceOfSupply: "PLANT001",
						WeightUnit: "KG",
						NetWeight: "14.30",
						CountryOfOrigin: "DE",
						CompetitorID: "COMP-7890",
						ProductGroup: "GRP-05",
						BaseUnit: "EA",
						ItemCategoryGroup: "NORM",
						ProductHierarchy: "001.002.003",
						Division: "10",
						VarblPurOrdUnitIsActive: "X",
						VolumeUnit: "L",
						MaterialVolume: "0.75",
						ANPCode: "123456",
						Brand: "SuperTech",
						ProcurementRule: "E",
						ValidityStartDate: "2025-09-18",
						LowLevelCode: "2",
						ProdNoInGenProdInPrepackProd: "GEN-998",
						SerialIdentifierAssgmtProfile: "PROF001",
						SizeOrDimensionText: "25x15x10 cm",
						IndustryStandardName: "ISO-9001",
						ProductStandardID: "04012345678901",
						InternationalArticleNumberCat: "EAN-13",
						ProductIsConfigurable: true,
						IsBatchManagementRequired: false,
						ExternalProductGroup: "EXT-GRP-88",
						CrossPlantConfigurableProduct: true,
						SerialNoExplicitnessLevel: "2",
						ProductManufacturerNumber: "MFR-ABC-999",
						ManufacturerNumber: "MFR-001",
						ManufacturerPartProfile: "MPROF-01",
						QltyMgmtInProcmtIsActive: true,
						IndustrySector: "M",
						ChangeNumber: "CHG-20250918",
						MaterialRevisionLevel: "A2",
						HandlingIndicator: "1",
						WarehouseProductGroup: "WPG-10",
						WarehouseStorageCondition: "DRY",
						StandardHandlingUnitType: "HUT01",
						SerialNumberProfile: "SER-001",
						AdjustmentProfile: "ADJ-PROF-1",
						PreferredUnitOfMeasure: "EA",
						IsPilferable: true,
						IsRelevantForHzdsSubstances: false,
						QuarantinePeriod: "30",
						TimeUnitForQuarantinePeriod: "D",
						QualityInspectionGroup: "QIG-01",
						AuthorizationGroup: "AUTH-10",
						DocumentIsCreatedByCAD: "X",
						HandlingUnitType: "HUT-STD",
						HasVariableTareWeight: true,
						MaximumPackagingLength: "120.0",
						MaximumPackagingWidth: "80.0",
						MaximumPackagingHeight: "60.0",
						UnitForMaxPackagingDimensions: "CM",
						toDescription: [
							{
								Language: "EN",
								ProductDescription: "High-Performance Industrial Pump",
							},
							{
								Language: "DE",
								ProductDescription: "Hochleistungspumpe für Industrie",
							},
							{
								Language: "IT",
								ProductDescription: "Pompa industriale ad alte prestazioni",
							},
						],
						toPlant: [
							{
								Plant: "3000",
								ProfitCenter: "PC1000",
								StorageLocation: "SL01",
							},
							{
								Plant: "4000",
								ProfitCenter: "PC2000",
								StorageLocation: "SL02",
							},
						],
						toProductBasicText: [
							{
								Language: "EN",
								LongText:
									"This pump is designed for continuous operation under high pressure.",
							},
						],
						toProductInspectionText: [
							{
								Language: "EN",
								InspectionText: "Must be inspected before shipment.",
							},
						],
						toProductProcurement: [
							{
								Plant: "3000",
								ProcurementType: "E",
								SpecialProcurement: "40",
								SourceListRequired: true,
							},
						],
						toProductPurchaseText: [
							{
								Language: "EN",
								PurchaseText: "Supplier must ensure ISO certification.",
							},
						],
						toProductQualityMgmt: [
							{
								Plant: "3000",
								InspLotSizInd: "1",
								InspType: "03",
								InspInterval: "6M",
							},
						],
						toProductSales: [
							{ SalesOrg: "1000", DistChannel: "10", DeliveringPlant: "3000" },
						],
						toProductSalesTax: [
							{ Country: "DE", TaxCategory: "MWST", TaxClassification: "1" },
						],
						toProductStorage: [
							{
								Plant: "3000",
								StorageConditions: "DRY",
								TempConditions: "15-25C",
							},
						],
						toProductUnitsOfMeasure: [
							{
								AltUnit: "BOX",
								Numerator: "10",
								Denominator: "1",
								UnitType: "Packaging",
							},
							{
								AltUnit: "PAL",
								Numerator: "50",
								Denominator: "1",
								UnitType: "Pallet",
							},
						],
						toSalesDelivery: [
							{
								DeliveryPlant: "3000",
								MinDeliveryQty: "5",
								DeliveryUnit: "EA",
							},
						],
						toValuation: [
							{
								ValuationArea: "3000",
								ValuationClass: "3001",
								PriceControl: "S",
								StandardPrice: "125.00",
							},
						],
					},
				};

				const systems = [
					"ADP",
					"Autodesk Vault",
					"Expense In",
					"Oracle Primavera",
					"SAP S/4 Hana",
					"SAP SuccessFactor",
					"Timesheet / Kiosk",
				];
				const results = [
					{
						IntegrationId: "INT-001",
						Code: "C001",
						KeyFields: [{ name: "KOSTL", value: "CC1001", type: "string" }],
						Description: "Cost Center TS",
						IntegrationDateTime: "2025-09-14T08:45:00",
						Status: "Success",
						Message: "Cost center data sent successfully.",
					},
					{
						IntegrationId: "INT-001A",
						Code: "C001",
						KeyFields: [{ name: "KOSTL", value: "CC1002", type: "string" }],
						Description: "Cost Center TS",
						IntegrationDateTime: "2025-09-14T09:00:00",
						Status: "Success",
						Message: "Additional cost center data sent.",
					},
					{
						IntegrationId: "INT-002",
						Code: "C002",
						KeyFields: [{ name: "PSPNR", value: "00000001", type: "string" }],
						Description: "WBE",
						IntegrationDateTime: "2025-09-14T09:00:00",
						Status: "Success",
						Message: "WBE elements synced successfully.",
					},
					{
						IntegrationId: "INT-002A",
						Code: "C002",
						KeyFields: [{ name: "PSPNR", value: "00000002", type: "string" }],
						Description: "WBE",
						IntegrationDateTime: "2025-09-14T09:15:00",
						Status: "Success",
						Message: "Extra WBE element synced.",
					},
					{
						IntegrationId: "INT-003",
						Code: "C003",
						KeyFields: [
							{ name: "AUFNR", value: "100000000001", type: "number" },
						],
						Description: "Network",
						IntegrationDateTime: "2025-09-14T10:00:00",
						Status: "Success",
						Message: "Network data sent successfully.",
					},
					{
						IntegrationId: "INT-003A",
						Code: "C003",
						KeyFields: [
							{ name: "AUFNR", value: "100000000002", type: "number" },
						],
						Description: "Network",
						IntegrationDateTime: "2025-09-14T10:30:00",
						Status: "Error",
						Message: "Network extra data failed.",
					},
					{
						IntegrationId: "INT-004",
						Code: "C004",
						KeyFields: [{ name: "AUFNR", value: "100001", type: "number" }],
						Description: "Production Order",
						IntegrationDateTime: "2025-09-14T11:00:00",
						Status: "Error",
						Message: "Failed to send production order.",
					},
					{
						IntegrationId: "INT-005",
						Code: "C005",
						KeyFields: [{ name: "LSTAR", value: "ACT001", type: "string" }],
						Description: "Activity Types",
						IntegrationDateTime: "2025-09-15T08:00:00",
						Status: "Success",
						Message: "Activity types sent successfully.",
					},
					{
						IntegrationId: "INT-006",
						Code: "C006",
						KeyFields: [{ name: "USRID", value: "jsmith", type: "string" }],
						Description: "Employee TS",
						IntegrationDateTime: "2025-09-15T09:30:00",
						Status: "Success",
						Message: "Employee TS data synced.",
					},
					{
						IntegrationId: "INT-007",
						Code: "C007",
						KeyFields: [{ name: "USRID", value: "amiller", type: "string" }],
						Description: "Employee S/4",
						IntegrationDateTime: "2025-09-15T10:00:00",
						Status: "Error",
						Message: "Failed to update Employee S/4.",
					},
					{
						IntegrationId: "INT-009",
						Code: "C009",
						KeyFields: [{ name: "KOSTL", value: "CC1001", type: "string" }],
						Description: "Cost Center ADP",
						IntegrationDateTime: "2025-09-15T12:00:00",
						Status: "Error",
						Message: "Failed to send Cost Center ADP data.",
					},
					{
						IntegrationId: "INT-010",
						Code: "C010",
						KeyFields: [
							{ name: "AUFNR", value: "100000000001", type: "string" },
						],
						Description: "Salary Accounting",
						IntegrationDateTime: "2025-09-16T09:00:00",
						Status: "Success",
						Message: "Salary accounting data sent successfully.",
					},
					{
						IntegrationId: "INT-011",
						Code: "C011",
						KeyFields: [{ name: "USRID", value: "amiller", type: "string" }],
						Description: "Tracking Activities",
						IntegrationDateTime: "2025-09-16T10:30:00",
						Status: "Success",
						Message: "Employee tracking activities synced successfully.",
					},
					{
						IntegrationId: "INT-015",
						Code: "C015",
						KeyFields: [
							{ name: "Product", value: "MAT-000123", type: "string" },
						],
						Description: "Vault Material",
						IntegrationDateTime: "2025-09-16T12:30:00",
						Status: "Success",
						Message: "Vault material created.",
					},
				].map((item) => ({
					...item,
					SysA: systems[Math.floor(Math.random() * systems.length)],
					SysB: systems[Math.floor(Math.random() * systems.length)],
				}));

				const resultsWithJson = results.map((r) => {
					let sKeysText = "";

					if (Array.isArray(r.KeyFields) && r.KeyFields.length) {
						sKeysText = r.KeyFields.map((oField) => {
							const sLabel =
								oBundle && oBundle.hasText(oField.name)
									? oBundle.getText(oField.name)
									: oField.name;
							return `${sLabel}: ${oField.value}`;
						}).join(", ");
					}
					let logs = [];
					switch (r.IntegrationId) {
						case "INT-001":
							logs = [
								{
									timestamp: "2025-09-14T08:45:00",
									type: "INFO",
									message: "Started Cost Center TS integration.",
								},
								{
									timestamp: "2025-09-14T08:46:00",
									type: "INFO",
									message: "Finished successfully.",
								},
							];
							break;
						case "INT-004":
							logs = [
								{
									timestamp: "2025-09-14T11:00:00",
									type: "ERROR",
									message: "Failed to send production order.",
								},
								{
									timestamp: "2025-09-14T11:01:00",
									type: "INFO",
									message: "Retry scheduled.",
								},
							];
							break;
						case "INT-010": // Salary Accounting
							logs = [
								{
									timestamp: "2025-09-16T09:00:00",
									type: "INFO",
									message: "Salary accounting started.",
								},
								{
									timestamp: "2025-09-16T09:05:00",
									type: "INFO",
									message: "Salary accounting completed successfully.",
								},
							];
							break;
						case "INT-011": // Tracking Activities
							logs = [
								{
									timestamp: "2025-09-16T10:30:00",
									type: "INFO",
									message: "Tracking activities sync started.",
								},
								{
									timestamp: "2025-09-16T10:35:00",
									type: "INFO",
									message: "Tracking activities synced successfully.",
								},
							];
							break;
						default:
							logs = [
								{
									timestamp: r.IntegrationDateTime,
									type: r.Status === "Success" ? "INFO" : "ERROR",
									message: r.Message,
								},
							];
					}
					return {
						...r,
						jsonContent: mapping[r.IntegrationId] || {},
						displayDescription: sKeysText
							? `${r.Description} - ${sKeysText}`
							: r.Description,
						logs: logs,
					};
				});

				const total = resultsWithJson.length;
				const success = resultsWithJson.filter(
					(r) => r.Status === "Success"
				).length;
				const failed = resultsWithJson.filter(
					(r) => r.Status === "Error"
				).length;

				return new sap.ui.model.json.JSONModel({
					integrationsColl: {
						Counts: { Total: total, Success: success, Failed: failed },
						results: resultsWithJson,
					},
				});
			},

			createMockData: function () {
				return new JSONModel({
					activityTypes: [
						{
							LSTAR: "ACT001",
							KTEXT: "Plant Maintenance",
							DATBI: "20251231",
							DATAB: "20240101",
							OPERA: "INS",
							positions: [
								{
									KOSTL: "CC1001",
									YEAR: "2025",
									MONTH: "01",
									PLAN: "X",
								},
								{
									KOSTL: "CC1002",
									YEAR: "2025",
									MONTH: "02",
									PLAN: "",
								},
							],
						},
						{
							LSTAR: "ACT002",
							KTEXT: "Production Line A",
							DATBI: "20251231",
							DATAB: "20240101",
							OPERA: "INS",
							positions: [
								{
									KOSTL: "CC1001",
									YEAR: "2025",
									MONTH: "03",
									PLAN: "X",
								},
							],
						},
						{
							LSTAR: "ACT003",
							KTEXT: "Quality Control",
							DATBI: "20251231",
							DATAB: "20230101",
							OPERA: "MOD",
							positions: [
								{
									KOSTL: "CC1002",
									YEAR: "2024",
									MONTH: "12",
									PLAN: "",
								},
							],
						},
						{
							LSTAR: "ACT004",
							KTEXT: "Operator Training",
							DATBI: "20221231",
							DATAB: "20210101",
							OPERA: "DEL",
							positions: [
								{
									KOSTL: "CC1003",
									YEAR: "2022",
									MONTH: "06",
									PLAN: "X",
								},
							],
						},
					],
					costCentersADP: [
						{
							code: "CCADP1001",
							name: "IT Department",
							DATBI: "20251231",
							DATAB: "20240101",
							inactiveIndicator: false,
						},
						{
							code: "CCADP1002",
							name: "HR Department",
							DATBI: "20251231",
							DATAB: "20240101",
							inactiveIndicator: true,
						},
						{
							code: "CCADP1003",
							name: "Finance Department",
							DATBI: "20241231",
							DATAB: "20220101",
							inactiveIndicator: false,
						},
					],
					employeesS4: [
						{
							USRID: "jsmith",
							HIRE_DATE: "20220110",
							BUKRS: "1000",
							WERKS: "2000",
							KOSTL: "CC1001",
							PERSG: "A1",
							PERSK: "A1-FT",
							BTRTL: "HQ01",
							ANRED: "Mr.",
							VORNA: "John",
							NACHN: "Smith",
							GBDAT: "19850412",
							GBORT: "London",
							NATIO: "UK",
							GESCH: "M",
							SPRSL: "EN",
							EMAIL: "john.smith@company.com",
							ADP_ID: "ADP12345",
							PERSON_ID_EXT: "SF1001",
							LSTAR: "ACT001",
							ICNUM: "AB123456C",
						},
						{
							USRID: "amiller",
							HIRE_DATE: "20210305",
							BUKRS: "2000",
							WERKS: "3000",
							KOSTL: "CC2001",
							PERSG: "B2",
							PERSK: "B2-PT",
							BTRTL: "PLT02",
							ANRED: "Ms.",
							VORNA: "Anna",
							NACHN: "Miller",
							GBDAT: "19900225",
							GBORT: "Berlin",
							NATIO: "DE",
							GESCH: "F",
							SPRSL: "DE",
							EMAIL: "anna.miller@company.com",
							ADP_ID: "ADP67890",
							PERSON_ID_EXT: "SF2001",
							LSTAR: "ACT002",
							ICNUM: "CD987654D",
						},
					],
					employeesTS: [
						{
							personIdExternal: "E1001",
							firstName: "John",
							lastName: "Doe",
							title: "Software Engineer",
							dateOfBirth: "19900115",
							gender: "M",
							status: "Active",
							emailAddress: "john.doe@company.com",
							companyEntryDate: "20220101",
							managerId: "M2001",
							hireDate: "20220101",
							terminationDate: "",
							employmentType: "Permanent",
							isFulltimeEmployee: true,
							employeeClass: "Regular",
							overtimePayed: "Y",
							fte: 1.0,
							department: "IT",
							legalEntity: "LE01",
							phoneNumber: "+1-202-555-0101",
							location: "New York",
							costCenter: "CC1001",
							standardHours: 40,
							jobCode: "ACT001",
							OPERA: "HIR",
						},
						{
							personIdExternal: "E1002",
							firstName: "Emily",
							lastName: "Smith",
							title: "HR Specialist",
							dateOfBirth: "19870322",
							gender: "F",
							status: "Active",
							emailAddress: "emily.smith@company.com",
							companyEntryDate: "20190515",
							managerId: "M2002",
							hireDate: "20190515",
							terminationDate: "",
							employmentType: "Permanent",
							isFulltimeEmployee: true,
							employeeClass: "Professional",
							overtimePayed: "N",
							fte: 1.0,
							department: "Human Resources",
							legalEntity: "LE01",
							phoneNumber: "+1-202-555-0152",
							location: "Chicago",
							costCenter: "CC1002",
							standardHours: 40,
							jobCode: "ACT003",
							OPERA: "MOD",
						},
						{
							personIdExternal: "E1003",
							firstName: "Michael",
							lastName: "Brown",
							title: "Marketing Manager",
							dateOfBirth: "19811205",
							gender: "M",
							status: "Terminated",
							emailAddress: "michael.brown@company.com",
							companyEntryDate: "20150110",
							managerId: "M2003",
							hireDate: "20150110",
							terminationDate: "20230930",
							employmentType: "Permanent",
							isFulltimeEmployee: true,
							employeeClass: "Manager",
							overtimePayed: "N",
							fte: 1.0,
							department: "Marketing",
							legalEntity: "LE02",
							phoneNumber: "+1-202-555-0198",
							location: "Los Angeles",
							costCenter: "CC1003",
							standardHours: 40,
							jobCode: "ACT002",
							OPERA: "TER",
						},
						{
							personIdExternal: "E1004",
							firstName: "Sophia",
							lastName: "Taylor",
							title: "Finance Analyst",
							dateOfBirth: "19950512",
							gender: "F",
							status: "Deleted",
							emailAddress: "sophia.taylor@company.com",
							companyEntryDate: "20200120",
							managerId: "M2004",
							hireDate: "20200120",
							terminationDate: "20210630",
							employmentType: "Contractor",
							isFulltimeEmployee: false,
							employeeClass: "Temporary",
							overtimePayed: "N",
							fte: 0.5,
							department: "Finance",
							legalEntity: "LE01",
							phoneNumber: "+1-202-555-0133",
							location: "Boston",
							costCenter: "CC1004",
							standardHours: 20,
							jobCode: "ACT004",
							OPERA: "DEL",
						},
					],

					orderHeaders: [
						{
							AUFNR: "100001",
							KTEXT: "Production A",
							AUART: "ZP01",
							STTXT: "REL",
							WERKS: "1000",
							PLNBEZ: "Material A",
							GAMNG: 500.0,
							GWEMG: 200.0,
							GSTRP: "20250901",
							GLTRP: "20250910",
							OPERA: "INS",
							operations: [
								{
									VORNR: "0010",
									LTXA1: "Operazione 1",
									SSAVD: "20250901",
									SSEVD: "20250905",
									VSTTXT: "ACT",
									ARBPL: "WC01",
									STEUS: "PP01",
									OPERA: "INS",
								},
								{
									VORNR: "0020",
									LTXA1: "Operazione 2",
									SSAVD: "20250906",
									SSEVD: "20250910",
									VSTTXT: "ACT",
									ARBPL: "WC02",
									STEUS: "PP02",
									OPERA: "INS",
								},
							],
						},
						{
							AUFNR: "100002",
							KTEXT: "Produzione B",
							AUART: "ZP02",
							STTXT: "TECO",
							WERKS: "1001",
							PLNBEZ: "Material B",
							GAMNG: 1000.0,
							GWEMG: 1000.0,
							GSTRP: "20250902",
							GLTRP: "20250912",
							OPERA: "MOD",
							operations: [
								{
									VORNR: "0010",
									LTXA1: "Operazione 1",
									SSAVD: "20250902",
									SSEVD: "20250906",
									VSTTXT: "CLO",
									ARBPL: "WC03",
									STEUS: "PP01",
									OPERA: "MOD",
								},
							],
						},
					],
					workCenters: [
						{
							ARBPL: "WC01",
							KTEXT: "Lavorazione A",
							OPERA: "INS",
						},
						{
							ARBPL: "WC02",
							KTEXT: "Lavorazione B",
							OPERA: "INS",
						},
						{
							ARBPL: "WC03",
							KTEXT: "Lavorazione C",
							OPERA: "MOD",
						},
					],
					plants: [
						{
							WERKS: "1000",
							NAME1: "Plant A",
							OPERA: "INS",
						},
						{
							WERKS: "1001",
							NAME1: "Plant B",
							OPERA: "MOD",
						},
					],
					wbeElements: [
						{
							PSPNR: "00000001",
							POSID: "WBS-IT-001",
							POST1: "IT Infrastructure Upgrade",
							PSTRT: "20230101",
							PENDE: "20231231",
							STTXT_EXT: "REL",
							OPERA: "INS",
						},
						{
							PSPNR: "00000002",
							POSID: "WBS-HR-001",
							POST1: "HR Onboarding System",
							PSTRT: "20230401",
							PENDE: "20231031",
							STTXT_EXT: "MOD",
							OPERA: "MOD",
						},
						{
							PSPNR: "00000003",
							POSID: "WBS-MKT-001",
							POST1: "Marketing Campaign 2022",
							PSTRT: "20220115",
							PENDE: "20221015",
							STTXT_EXT: "CLSD",
							OPERA: "DEL",
						},
						{
							PSPNR: "00000004",
							POSID: "WBS-RND-001",
							POST1: "R&D Project Alpha",
							PSTRT: "20230501",
							PENDE: "20241231",
							STTXT_EXT: "REL",
							OPERA: "INS",
						},
						{
							PSPNR: "00000005",
							POSID: "WBS-SUP-001",
							POST1: "Supplier Integration",
							PSTRT: "20230701",
							PENDE: "20231201",
							STTXT_EXT: "REL",
							OPERA: "MOD",
						},
					],
					costCenters: [
						{
							KOSTL: "CC1001",
							BUKRS: "C001",
							LTEXT: "Cost Center for IT Department",
							DATBI: "20230101",
							DATAB: "20241231",
							OPERA: "INS",
						},
						{
							KOSTL: "CC1002",
							BUKRS: "C002",
							LTEXT: "Cost Center for HR Department",
							DATBI: "20230101",
							DATAB: "20241231",
							OPERA: "MOD",
						},
						{
							KOSTL: "CC1003",
							BUKRS: "C003",
							LTEXT: "Obsolete Marketing Cost Center",
							DATBI: "20220101",
							DATAB: "20221231",
							OPERA: "DEL",
						},
					],
					network: [
						{
							AUFNR: "100000000001",
							KTEXT: "Network Description 1",
							PSPNR: "00000001",
							GSTRP: "20230101",
							GLTRP: "20231231",
							OPERA: "INS",
							STATUS: "INS",
							DATEOP: "20231102",
							operations: [
								{
									VORNR: "0001",
									LTXA1: "Operation 1 Description",
									NTANF: "20230110",
									NTEND: "20230120",
									VSTTXT: "REL",
									OPERA: "INS",
									STATUS: "INS",
									DATEOP: "20231102",
								},
								{
									VORNR: "0002",
									LTXA1: "Operation 2 Description",
									NTANF: "20230115",
									NTEND: "20230125",
									VSTTXT: "CLSD",
									OPERA: "MOD",
									STATUS: "MOD",
									DATEOP: "20231102",
								},
							],
							log: [
								{
									AUFNR: "100000000001",
									VORNR: "",
									AUTHMOD: "john.doe",
									MODDATE: "20230901",
									MODTIME: "083015",
									MODOBJ: "KTEXT",
									OLDVAL: "Old Network Description",
									NEWVAL: "Updated Network Description",
									STATUS: "MOD",
								},
								{
									AUFNR: "100000000001",
									VORNR: "0001",
									AUTHMOD: "jane.smith",
									MODDATE: "20230902",
									MODTIME: "101530",
									MODOBJ: "LTXA1",
									OLDVAL: "Initial Description",
									NEWVAL: "Refined Operation 1 Description",
									STATUS: "MOD",
								},
								{
									AUFNR: "100000000001",
									VORNR: "0002",
									AUTHMOD: "admin",
									MODDATE: "20230903",
									MODTIME: "111200",
									MODOBJ: "STATUS",
									OLDVAL: "REL",
									NEWVAL: "CLSD",
									STATUS: "MOD",
								},
								{
									AUFNR: "100000000001",
									VORNR: "0002",
									AUTHMOD: "admin",
									MODDATE: "20230703",
									MODTIME: "111200",
									MODOBJ: "",
									OLDVAL: "",
									NEWVAL: "",
									STATUS: "INS",
								},
							],
						},
						{
							AUFNR: "100000000002",
							KTEXT: "Network Description 2",
							PSPNR: "00000002",
							GSTRP: "20230201",
							GLTRP: "20231231",
							OPERA: "MOD",
							STATUS: "MOD",
							DATEOP: "20231102",
							operations: [
								{
									VORNR: "0001",
									LTXA1: "Operation 1 Description",
									NTANF: "20230205",
									NTEND: "20230215",
									VSTTXT: "REL",
									OPERA: "MOD",
									STATUS: "MOD",
									DATEOP: "20231102",
								},
							],
						},
						{
							AUFNR: "100000000003",
							KTEXT: "Network Description 1",
							PSPNR: "00000003",
							GSTRP: "20230101",
							GLTRP: "20231231",
							OPERA: "INS",
							STATUS: "INS",
							DATEOP: "20231102",
							operations: [
								{
									VORNR: "0001",
									LTXA1: "Operation 1 Description",
									NTANF: "20230110",
									NTEND: "20230120",
									VSTTXT: "REL",
									OPERA: "INS",
									STATUS: "INS",
									DATEOP: "20231102",
								},
								{
									VORNR: "0002",
									LTXA1: "Operation 2 Description",
									NTANF: "20230115",
									NTEND: "20230125",
									VSTTXT: "CLSD",
									OPERA: "MOD",
									STATUS: "MOD",
									DATEOP: "20231102",
								},
							],
							log: [
								{
									AUFNR: "100000000003",
									VORNR: "",
									AUTHMOD: "john.doe",
									MODDATE: "20230901",
									MODTIME: "083015",
									MODOBJ: "KTEXT",
									OLDVAL: "Old Network Description",
									NEWVAL: "Updated Network Description",
									STATUS: "MOD",
								},
								{
									AUFNR: "100000000003",
									VORNR: "0001",
									AUTHMOD: "jane.smith",
									MODDATE: "20230902",
									MODTIME: "101530",
									MODOBJ: "LTXA1",
									OLDVAL: "Initial Description",
									NEWVAL: "Refined Operation 1 Description",
									STATUS: "MOD",
								},
								{
									AUFNR: "100000000003",
									VORNR: "0002",
									AUTHMOD: "admin",
									MODDATE: "20230903",
									MODTIME: "111200",
									MODOBJ: "STATUS",
									OLDVAL: "REL",
									NEWVAL: "CLSD",
									STATUS: "MOD",
								},
								{
									AUFNR: "100000000003",
									VORNR: "0002",
									AUTHMOD: "admin",
									MODDATE: "20230703",
									MODTIME: "111200",
									MODOBJ: "",
									OLDVAL: "",
									NEWVAL: "",
									STATUS: "INS",
								},
							],
						},
					],
				});
			},
		};
	}
);
